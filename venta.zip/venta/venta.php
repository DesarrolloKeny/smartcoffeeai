<?php
session_start();
include_once('../controlador/conexion.php');

if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../login.php');
    exit;
}
$id_usuario = $_SESSION['id_usuario'];
$rol = $_SESSION['rol'] ?? 'vendedor'; 
$nombre_usuario = $_SESSION['nombre'] ?? 'Usuario';

// --- VALIDACIÓN DE ESTADO DE CAJA ---
$stmtCaja = $pdo->query("SELECT id_caja, estado FROM caja ORDER BY id_caja DESC LIMIT 1");
$cajaInfo = $stmtCaja->fetch();
$is_caja_abierta = ($cajaInfo && $cajaInfo['estado'] == 'abierta');

// Configuración de colores para el indicador de caja
$bg_caja = $is_caja_abierta ? 'bg-gradient-success' : 'bg-gradient-danger';
$icon_caja = $is_caja_abierta ? 'fa-unlock' : 'fa-lock';
$texto_caja = $is_caja_abierta ? 'ABIERTA' : 'CERRADA';

// --- CONSULTAS ---
$productos_db = $pdo->query("SELECT id_producto, nombre, precio, stock FROM productos WHERE activo = 1 AND stock > 0 ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC);
$ventas_hoy = $pdo->query("SELECT v.*, c.nombre as cliente FROM ventas v LEFT JOIN clientes c ON v.id_cliente = c.id_cliente WHERE DATE(v.fecha) = CURDATE() ORDER BY v.fecha DESC")->fetchAll(PDO::FETCH_ASSOC);

$total_ventas_valor = array_sum(array_column($ventas_hoy, 'total'));
$stock_bajo = $pdo->query("SELECT COUNT(*) FROM productos WHERE stock <= 10 AND activo = 1")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <title>SmartCoffee AI</title>
    <link rel="icon" type="image/png" href="../assets/img/logo.png">
    <link href="../css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root { --primary-coffee: #6F4E37; --secondary-orange: #E67E22; }
        body { background-color: #f0f2f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }

        #layoutSidenav_nav .sb-sidenav { background: linear-gradient(180deg, #212529 0%, #2c3e50 100%) !important; }
        .sb-sidenav-menu .nav-link.active { background: linear-gradient(45deg, var(--primary-coffee), var(--secondary-orange)) !important; color: #fff !important; }
        
        .status-dot { height: 10px; width: 10px; border-radius: 50%; display: inline-block; margin-left: auto; border: 2px solid rgba(255,255,255,0.2); }
        .dot-online { background-color: #2ecc71; box-shadow: 0 0 8px #2ecc71; }
        .dot-offline { background-color: #e74c3c; box-shadow: 0 0 8px #e74c3c; }

        .bg-gradient-primary { background: linear-gradient(45deg, #4e73df 0%, #224abe 100%); }
        .bg-gradient-success { background: linear-gradient(45deg, #1cc88a 0%, #13855c 100%); }
        .bg-gradient-danger { background: linear-gradient(45deg, #e74c3c 0%, #c0392b 100%); }
        .bg-gradient-warning { background: linear-gradient(45deg, #f6c23e 0%, #dda20a 100%); }
        
        .card-reporte { border: none; transition: transform 0.2s; border-radius: 12px; }
        .icon-circle { height: 3rem; width: 3rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.2); }

        .carrito-scroll { min-height: 400px; max-height: 400px; overflow-y: auto; background: #fff; border-radius: 12px; border: 1px solid #dee2e6; }
        .total-panel { background: #1a1d20; color: #fff; border-radius: 12px; padding: 20px; }
        .opacity-closed { filter: grayscale(1); opacity: 0.5; pointer-events: none; }
        
        .venta-item { transition: background 0.2s; border-bottom: 1px solid #eee; }
        .venta-item:hover { background-color: #f8f9fa !important; }
        .btn-print { color: #6c757d; transition: color 0.2s; }
        .btn-print:hover { color: #000; }
    </style>
    <style>
    /* Contenedor circular blanco para el logo */
    .logo-circle {
        background-color: #ffffff;
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 4px; /* Espacio entre el borde del círculo y el logo */
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        flex-shrink: 0; /* Evita que el círculo se deforme */
    }

    /* Ajuste de la imagen dentro del círculo */
    .logo-circle img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
    }

    /* Ajustes responsivos para móviles */
    @media (max-width: 576px) {
        .logo-circle {
            width: 32px;
            height: 32px;
            padding: 3px;
        }
        
        .navbar-brand {
            padding-left: 0.5rem !important;
        }
    }
</style>
</head>
<body class="sb-nav-fixed">
<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark shadow">
    <a class="navbar-brand ps-3 d-flex align-items-center" href="../Dashboard/panel.php">
        <span class="logo-circle me-2">
            <img src="../assets/img/logo.png" alt="SmartCoffee Logo">
        </span>
        <span class="fw-bold d-none d-sm-inline text-white">
            SmartCoffee <span class="text-warning">AI</span>
        </span>
    </a>

    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0 text-white-50" id="sidebarToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="ms-auto"></div>

    <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown">
                <i class="fas fa-user-circle fa-lg"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                <li><a class="dropdown-item py-2" href="../usuarios/register.php"><i class="fas fa-id-card me-2 opacity-50"></i>Mi Perfil</a></li>
                <li><hr class="dropdown-divider" /></li>
                <li><a class="dropdown-item py-2 text-danger" href="../usuarios/cerrar.php"><i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión</a></li>
            </ul>
        </li>
    </ul>
</nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="../Dashboard/panel.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Panel
                        </a>
                        <div class="sb-sidenav-menu-heading">Gestión</div>
                        <a class="nav-link" href="../venta/venta.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Ventas
                        </a>
                        <?php if ($rol === 'admin'): ?>
                        <a class="nav-link" href="../productos/GestionProducto.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-coffee"></i></div>
                            Productos
                        </a>
                        <?php elseif ($rol === 'vendedor'): ?>
                        <a class="nav-link" href="../productos/GestionProducto.php" title="Solo lectura">
                            <div class="sb-nav-link-icon"><i class="fas fa-coffee"></i></div>
                            Productos
                        </a>
                        <?php endif; ?>
                        <?php if ($rol === 'admin' || $rol === 'vendedor'): ?>
                        <a class="nav-link" href="../recetas/GestionResetas.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                            Recetas
                        </a>
                        <?php endif; ?>
                        <?php if ($rol === 'admin'): ?>
                        <a class="nav-link" href="../stock/GestionStock.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-warehouse"></i></div>
                            Stock
                        </a>
                        <?php elseif ($rol === 'vendedor'): ?>
                        <a class="nav-link" href="../stock/GestionStock.php" title="Solo lectura">
                            <div class="sb-nav-link-icon"><i class="fas fa-warehouse"></i></div>
                            Stock (Lectura)
                        </a>
                        <?php endif; ?>
                        <a class="nav-link" href="../cliente/GestionCliente.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Clientes
                        </a>
                        <?php if ($rol === 'admin'): ?>
                        <a class="nav-link" href="../usuarios/GestionUsuario.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user-cog"></i></div>
                            Usuarios
                        </a>
                        <?php endif; ?>
                        <div class="sb-sidenav-menu-heading">Addons</div>
                        <?php if ($rol === 'admin'): ?>
                        <a class="nav-link" href="../Reporte/reporte.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-file-alt"></i></div>
                            Reportes
                        </a>
                        <?php elseif ($rol === 'vendedor'): ?>
                        <a class="nav-link" href="../Reporte/reporte.php" title="Solo sus ventas">
                            <div class="sb-nav-link-icon"><i class="fas fa-file-alt"></i></div>
                            Reportes (Limitado)
                        </a>
                        <?php endif; ?>
                        <a class="nav-link active" href="../caja/caja.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-cash-register"></i></div>
                            Caja
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Conectado como:</div>
                    <?php echo htmlspecialchars($nombre_usuario); ?> <br>
                    <?php echo ucfirst($rol); ?>
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main class="p-4">
                <div class="container-fluid">
                    <div class="row g-3 mb-4">
                        <div class="col-xl-4 col-md-6">
                            <div class="card card-reporte bg-gradient-primary text-white shadow">
                                <div class="card-body py-3 d-flex align-items-center justify-content-between">
                                    <div>
                                        <div class="small fw-bold opacity-75">VENTAS HOY</div>
                                        <div class="h3 mb-0 fw-bold">$<?php echo number_format($total_ventas_valor, 0, ',', '.'); ?></div>
                                    </div>
                                    <div class="icon-circle"><i class="fas fa-shopping-basket"></i></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-md-6">
                            <div class="card card-reporte <?php echo $bg_caja; ?> text-white shadow">
                                <div class="card-body py-3 d-flex align-items-center justify-content-between">
                                    <div>
                                        <div class="small fw-bold opacity-75">ESTADO CAJA</div>
                                        <div class="h3 mb-0 fw-bold"><?php echo $texto_caja; ?></div>
                                    </div>
                                    <div class="icon-circle"><i class="fas <?php echo $icon_caja; ?>"></i></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-6">
                            <div class="card card-reporte <?php echo $stock_bajo > 0 ? 'bg-gradient-warning' : 'bg-gradient-primary'; ?> text-white shadow">
                                <div class="card-body py-3 d-flex align-items-center justify-content-between">
                                    <div>
                                        <div class="small fw-bold opacity-75">ALERTAS STOCK</div>
                                        <div class="h3 mb-0 fw-bold"><?php echo $stock_bajo; ?> Prod.</div>
                                    </div>
                                    <div class="icon-circle"><i class="fas fa-exclamation-triangle"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row g-4">
                    <div class="col-lg-8">
    <div class="card border-0 shadow-sm <?php echo !$is_caja_abierta ? 'opacity-closed' : ''; ?>">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-cash-register me-2 text-primary"></i>Nueva Venta</h5>
            <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="abrirModalProductos()">
                <i class="fas fa-plus me-1"></i> Agregar Producto
            </button>
        </div>
        <div class="card-body">
            <div class="row g-3 mb-4">
                <div class="col-md-7">
                    <label class="small fw-bold mb-1">Cliente (RUT o Nombre)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-user"></i></span>
                        <input type="text" id="buscar_cliente" class="form-control" placeholder="Escribe para buscar..." autocomplete="off">
                        <input type="hidden" id="id_cliente_seleccionado" value="">
                    </div>
                    <div id="resultados_cliente" class="list-group position-absolute w-100 shadow-sm" style="z-index: 1000;"></div>
                </div>
                <div class="col-md-5">
                    <label class="small fw-bold mb-1">Método de Pago</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-wallet"></i></span>
                        <select id="metodo_pago" class="form-select">
                            <option value="efectivo">Efectivo</option>
                            <option value="transferencia">Transferencia</option>
                            <option value="debito">Débito / Crédito</option>
                        </select>
                    </div>
                </div>
            </div>

            <div id="contenedor_carrito" class="carrito-scroll p-0 mb-4">
                <table class="table table-hover align-middle mb-0" id="tabla_carrito">
                    <thead class="table-light sticky-top">
                        <tr>
                            <th class="ps-3">Producto</th>
                            <th width="100">Cant.</th>
                            <th width="120">Precio</th>
                            <th width="120">Subtotal</th>
                            <th width="50"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr id="carrito_vacio">
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-shopping-cart fa-3x mb-3 opacity-25"></i>
                                <p>No hay productos en la venta</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="total-panel d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 small d-block">Total a pagar</span>
                    <h2 class="mb-0 fw-bold text-warning" id="txt_total_venta">$ 0</h2>
                </div>
                <button class="btn btn-success btn-lg px-5 fw-bold rounded-pill shadow-sm" onclick="finalizarVenta()">
                    <i class="fas fa-check-circle me-2"></i>FINALIZAR VENTA
                </button>
            </div>
        </div>
    </div>
</div>

                        <div class="col-lg-4">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-dark text-white fw-bold small py-3">VENTAS RECIENTES</div>
                                <div class="list-group list-group-flush overflow-auto" style="max-height: 550px;">
                                    <?php foreach($ventas_hoy as $v): ?>
                                    <div class="list-group-item venta-item border-start border-4 <?php echo ($v['metodo_pago']=='efectivo'?'border-success':'border-info'); ?>">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div onclick="verDetalleVenta(<?php echo $v['id_venta']; ?>)" style="cursor:pointer; flex-grow:1;">
                                                <div class="d-flex justify-content-between">
                                                    <span class="fw-bold text-primary">#<?php echo $v['id_venta']; ?></span>
                                                    <small class="text-muted"><?php echo date('H:i', strtotime($v['fecha'])); ?></small>
                                                </div>
                                                <div class="small text-truncate"><?php echo htmlspecialchars($v['cliente'] ?? 'Público General'); ?></div>
                                                <div class="fw-bold">$<?php echo number_format($v['total'], 0, ',', '.'); ?></div>
                                            </div>
                                            <div class="ps-2">
                                                <button class="btn btn-link btn-print" title="Imprimir Voucher" onclick="imprimirVoucher(<?php echo $v['id_venta']; ?>)">
                                                    <i class="fas fa-print fa-lg"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>

document.getElementById('buscar_cliente').addEventListener('input', function() {
    let query = this.value;
    if (query.length >= 2) {
        fetch(`buscar_cliente.php?q=${query}`)
            .then(res => res.json())
            .then(data => {
                let html = '';
                data.forEach(c => {
                    html += `
                        <button type="button" class="list-group-item list-group-item-action" 
                                onclick="seleccionarCliente(${c.id_cliente}, '${c.nombre}')">
                            <strong>${c.rut}</strong> - ${c.nombre}
                        </button>`;
                });
                document.getElementById('resultados_cliente').innerHTML = html;
            });
    } else {
        document.getElementById('resultados_cliente').innerHTML = '';
    }
});

function seleccionarCliente(id, nombre) {
    document.getElementById('id_cliente_seleccionado').value = id;
    document.getElementById('buscar_cliente').value = nombre;
    document.getElementById('resultados_cliente').innerHTML = '';
}

        // Toggle Sidebar
        window.addEventListener('DOMContentLoaded', event => {
            const sidebarToggle = document.body.querySelector('#sidebarToggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', event => {
                    event.preventDefault();
                    document.body.classList.toggle('sb-sidenav-toggled');
                });
            }
        });

        // Ver Detalle Venta
        function verDetalleVenta(idVenta) {
            Swal.fire({
                title: 'Cargando detalle...',
                didOpen: () => { Swal.showLoading(); }
            });
            fetch(`get_detalle_venta.php?id_venta=${idVenta}`)
                .then(r => r.text())
                .then(html => {
                    Swal.fire({
                        title: `<i class="fas fa-receipt me-2"></i>Venta #${idVenta}`,
                        html: html,
                        width: '600px',
                        confirmButtonColor: '#6F4E37'
                    });
                });
        }

        // FUNCIÓN PARA IMPRIMIR VOUCHER
        function imprimirVoucher(idVenta) {
            const ancho = 400;
            const alto = 600;
            const x = (screen.width / 2) - (ancho / 2);
            const y = (screen.height / 2) - (alto / 2);
            window.open(`generar_voucher.php?id_venta=${idVenta}`, 'Voucher', 
                        `width=${ancho},height=${alto},left=${x},top=${y},scrollbars=yes`);
        }
    </script>
</body>
</html>