<?php
include_once('../controlador/conexion.php');
$id_venta = $_GET['id_venta'];

// Traer datos de la venta, cliente y productos (basado en tu SQL)
$query = "SELECT v.*, u.nombre as vendedor, c.nombre as cliente 
          FROM ventas v 
          JOIN usuarios u ON v.id_usuario = u.id_usuario 
          LEFT JOIN clientes c ON v.id_cliente = c.id_cliente 
          WHERE v.id_venta = :id";
$stmt = $pdo->prepare($query);
$stmt->execute(['id' => $id_venta]);
$venta = $stmt->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ticket #<?php echo $id_venta; ?></title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; width: 300px; font-size: 12px; }
        .text-center { text-align: center; }
        .divider { border-top: 1px dashed #000; margin: 10px 0; }
        table { width: 100%; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print()">
    <div class="text-center">
        <h3>SMART COFFEE</h3>
        <p>Venta #<?php echo $id_venta; ?><br>
        Fecha: <?php echo $venta['fecha']; ?></p>
    </div>
    <div class="divider"></div>
    <p>Cajero: <?php echo $venta['vendedor']; ?><br>
       Cliente: <?php echo $venta['cliente'] ?? 'Publico General'; ?></p>
    <div class="divider"></div>
    <p>TOTAL: $<?php echo number_format($venta['total'], 0, ',', '.'); ?></p>
    <div class="text-center">
        <p>¡Gracias por su compra!</p>
    </div>
    <button class="no-print" onclick="window.close()">Cerrar</button>
</body>
</html>